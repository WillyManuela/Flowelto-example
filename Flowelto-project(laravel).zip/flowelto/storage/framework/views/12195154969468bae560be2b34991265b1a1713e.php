

<?php $__env->startSection('main-content'); ?>
<div style="height:40%; width:40%; margin-left: 30%; margin-top: 2%">
    <div style="text-align: center">
    <label class="form-check-label pt-2 pb-3" style="font-size: 20px">Register</label></div>
    <form style="padding:5px" action="<?php echo e(route('register')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="bd-example" style="text-align: right">
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-4 col-form-label">Username</label>
          <div class="col-sm-7">
            <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>">
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-4 col-form-label">E-mail Address</label>
            <div class="col-sm-7">
              <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
            </div>
          </div>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-4 col-form-label">Password</label>
            <div class="col-sm-7">
              <input type="password" class="form-control" name="password">
            </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 row">
            <label class="col-sm-4 col-form-label">Confirm Password</label>
            <div class="col-sm-7">
              <input type="password" class="form-control" name="confirm">
            </div>
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <fieldset class="form-group ">
            <div class="mb-3 row">
                <legend class="col-sm-4 col-form-label" style="text-align: right">Gender</legend>
                <div class="col-sm-3">
                    <input class="form-check-input mt-2" type="radio" name="gender" value="Male">
                    <label class="col-sm-4 col-form-label">Male</label>
                </div>
                <div class="col-sm-3">
                    <input class="form-check-input mt-2" type="radio" name="gender" value="Female">
                    <label class="col-sm-4 col-form-label">Female</label>
                </div>
            </div>
        </fieldset>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 row" style="text-align: right">
          <label class="col-sm-4 col-form-label">Date Of Birth</label>
          <div class="col-sm-7">
            <input type="date" class="form-control" name="dob" value="<?php echo e(old('dob')); ?>">
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 row" style="text-align: right">
          <label class="col-sm-4 col-form-label">Address</label>
          <div class="col-sm-7">
            <textarea  class="form-control" name="address" value="<?php echo e(old('address')); ?>"></textarea>
          </div>
        </div>
        <button type="submit" class="btn btn-primary mb-4" style="margin-left:35%">Register</button>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WPprojectLab\flowelto\resources\views/register.blade.php ENDPATH**/ ?>