

<?php $__env->startSection('main-content'); ?>
    <div style="margin-left: 10%; margin-right: 10%; margin-top: 2%; display: flex">
        <div>
            <img src="<?php echo e(asset('assets/category/'.$category->img)); ?>" height="400px" width="400px">
        </div>
        <form action="<?php echo e(route('updatecategory',$category->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
            <div style="margin-left: 5%" >
                <div style="text-align: right">
                    <div style="text-align: left; margin-left:35%">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: red"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 row" >
                        <label class="col-sm-4 col-form-label">Category Name</label>
                        <div class="col-sm-8" >
                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e($category->name); ?>">
                        </div>
                    </div>
                    <div style="text-align: left; margin-left:35%">
                        <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: red"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-4 col-form-label">Category Image</label>
                        <div class="col-sm-8">
                        <input type="file" class="form-control" name="img" value="<?php echo e(old('img')); ?>">
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary mb-4 mr-4" style="margin-left:35%">Update</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jk\Willy - WP\flowelto\resources\views/updatecategory.blade.php ENDPATH**/ ?>