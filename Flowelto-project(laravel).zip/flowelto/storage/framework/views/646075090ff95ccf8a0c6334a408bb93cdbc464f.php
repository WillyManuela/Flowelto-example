

<?php $__env->startSection('main-content'); ?>
<div style="margin-left: 10%; margin-top:1%; margin-right: 10%; margin-bottom:2%">
    <div style="text-align: center">
        <label style="font-size: 35px; font-style: italic; font-weight: 500">Manage Category</label><br>
    </div>
    <div>
        <div class="row row-cols-2 row-cols-md-3 mt-3 ml-2">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col mb-4 mr-2">
                    <div class="card" style="background-color: #fe80bf; text-align: center">
                        <img src="<?php echo e(asset('assets/category/'.$c->img)); ?>" class="card-img-top" height="350px" width="350px" style="padding:2%">
                        <div class="card-body">
                            <label><?php echo e($c->name); ?></label><br>
                        </div>
                        <div class="mb-2"style="display: flex; margin-left:3.5%">
                            <div style="margin-left: 10%">
                                <form action="<?php echo e(route('deletecategory',$c->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('POST'); ?>
                                    <button type="submit" class="btn btn-danger">Delete Category</button>
                                </form>
                            </div>
                            <div style="margin-left: 1%">
                                <a href="<?php echo e(route('updatecategory',$c->id)); ?>" class="btn btn-primary">Update Category</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WPprojectLab\flowelto\resources\views/managecategories.blade.php ENDPATH**/ ?>