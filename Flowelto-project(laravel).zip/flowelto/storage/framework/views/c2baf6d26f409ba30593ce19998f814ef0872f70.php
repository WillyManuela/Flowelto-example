

<?php $__env->startSection('main-content'); ?>
    <div style="margin-left: 10%; margin-right: 10%; margin-top: 2%; display: flex">
        <div>
            <img src="<?php echo e(asset('assets/flower/'.$flower->img)); ?>" height="500px" width="500px">
        </div>
        <div style="margin-left: 10%">
            <label style="font-size: 32px; font-weight: 550"><?php echo e($flower->name); ?></label><br>
            <label class="mt-2" style="font-size: 28px; font-weight: 450">Rp <?php echo e($flower->price); ?></label><br>
            <label class="mt-2" style="font-size: 20px"><?php echo e($flower->description); ?></label>
            <?php if(!(Auth::User() && Auth::User()->role->name == 'Manager')): ?>
            <form action="<?php echo e(route('addtocart',$flower->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <div style="margin-top: 20px">
                    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div style="display: flex">
                        <div><label for="staticEmail" class="col-form-label">Quantity :</label></div>
                        <div class="col-sm-15" style="margin-left: 15px">
                        <input class="form-control"type="number" name="quantity" value="<?php echo e(old('quantity')); ?>"></div>
                    </div>
                    <button class="btn btn-primary" type="submit" style="margin-top: 20px; margin-left: 80px">Add To Cart</button>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jk\Willy - WP\flowelto\resources\views/flowerdetail.blade.php ENDPATH**/ ?>