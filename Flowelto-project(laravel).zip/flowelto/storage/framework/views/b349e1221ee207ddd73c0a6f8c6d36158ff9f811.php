

<?php $__env->startSection('main-content'); ?>
<div style="margin-left: 10%; margin-right:10%;margin-top: 2%">
    <div style="text-align: center">
        <label class="form-check-label pt-2 pb-3" style="font-size: 25px; font-weight: 600">Your Transaction at <?php echo e($transaction->date); ?></label>
    </div>
    <div style=" margin-left:2%; margin-right: 2%; text-align: right">
        <table class="table" style="background-color: #a97f81; text-align:center">
            <thead>
              <tr>
                <th scope="col">Flower Image</th>
                <th scope="col">Flower Name</th>
                <th scope="col">Subtotal</th>
                <th scope="col">Quantity</th>
              </tr>
            </thead>
            <?php $total = 0; ?>
            <tbody>
                <?php $__currentLoopData = $transaction->transactiondetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img src="<?php echo e(asset('assets/flower/'.$td->flower->img)); ?>" width="150px" height="150px"></td>
                        <td><?php echo e($td->flower->name); ?></td>
                        <td><?php echo e($td->flower->price * $td->quantity); ?></td>
                        <td><?php echo e($td->quantity); ?></td>
                    </tr>
                    <?php $total = $total + $td->quantity * $td->flower->price; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <label style="width: inherit; font-weight: 600">Total Price: Rp <?php echo e($total); ?></label>
    </div>
    <br><br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jk\Willy - WP\flowelto\resources\views/transactiondetail.blade.php ENDPATH**/ ?>