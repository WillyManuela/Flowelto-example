

<?php $__env->startSection('main-content'); ?>
<div style="height:40%; width:40%; margin-left: 30%; margin-top: 2%">
    <div style="text-align: center">
    <label class="form-check-label pt-2 pb-3" style="font-size: 20px">Add Flower</label></div>
    <?php if(session('success')): ?>
    <div style="text-align: center; margin-bottom:2%">
    <label class="text-success">
        <?php echo e(session('success')); ?>

    </label></div>
    <?php endif; ?>
    <form style="padding:5px" action="<?php echo e(route('addflower')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="bd-example" style="text-align: right">
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-4 col-form-label">Category</label>
          <div class="col-sm-7">
            <select class="form-select form-control" aria-label=".form-select-lg example" name="category">
                <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>" name="category"><?php echo e($c->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-4 col-form-label">Flower Name</label>
            <div class="col-sm-7">
              <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
            </div>
          </div>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 row" style="text-align: right">
          <label class="col-sm-4 col-form-label">Flower Price (Rupiah)</label>
          <div class="col-sm-7">
            <input type="number" class="form-control" name="price" value="<?php echo e(old('price')); ?>">
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 row" style="text-align: right">
          <label class="col-sm-4 col-form-label">Description</label>
          <div class="col-sm-7">
            <textarea  class="form-control" name="description" value="<?php echo e(old('description')); ?>"></textarea>
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 row">
            <div class="col-sm-1"></div>
            <label for="staticEmail" class="col-sm-3 col-form-label">Flower Image</label>
            <div class="col-sm-7">
              <input type="file" class="form-control" name="img" value="<?php echo e(old('img')); ?>">
            </div>
        </div>
    </div>
    <button type="submit" class="btn btn-primary mb-4 mr-4" style="margin-left:35%">Add</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WPprojectLab\flowelto\resources\views/addflower.blade.php ENDPATH**/ ?>