

<?php $__env->startSection('main-content'); ?>
<div style="margin-left: 10%; margin-top:1%; margin-right: 10%; margin-bottom:2%">
    <div style="text-align: center">
        <label style="font-size: 35px; font-style: italic; font-weight: 500">Our <?php echo e($category->name); ?></label><br>
    </div>
    <div >
        <form action="<?php echo e(route('category',$category->id)); ?>">
            <?php echo csrf_field(); ?>
            <div class="col-sm-12" style="display:flex">
                <div style="margin-right:1%">
                <select class="form-select mb-3 form-control" aria-label=".form-select-lg example" name="select">
                    <option value="name" name="select">Name</option>
                    <option value="price" name="select">Price</option>
                </select></div>
                <div><input type="text" class="form-control" name="search" placeholder="Search"  value="<?php echo e(Request::input('search')); ?>"></div>
                <div style="margin-left:2%"><button type="submit" class="btn btn-primary">Search</button></div>
            </div>
        </form>
    </div>
    <div>
        <div class="row row-cols-2 row-cols-md-4 mt-3 ml-2">
            <?php $__currentLoopData = $category->flowers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('detail',$f->id)); ?>" style="text-decoration: none; color: black">
                    <div class="col mb-4 mr-2">
                        <div class="card" style="background-color: #fe80bf; text-align: center">
                            <img src="<?php echo e(asset('assets/flower/'.$f->img)); ?>" class="card-img-top" height="350px" width="350px" style="padding:2%">
                            <div class="card-body">
                                <label><?php echo e($f->name); ?></label><br>
                                <label>Rp. <?php echo e($f->price); ?></label>
                            </div>
                            <?php if(Auth::User() && Auth::User()->role->name == 'Manager'): ?>
                            <div class="mb-2"style="display: flex; margin-left:3.5%">
                                <div>
                                    <form action="<?php echo e(route('deleteflower',$f->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <button type="submit" class="btn btn-danger">Delete Flower</button>
                                    </form>
                                </div>
                                <div style="margin-left: 5%">
                                    <form action="<?php echo e(route('updateflower',$f->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-primary">Update Flower</button>
                                    </form>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div style="margin-left:45%"> 
            <?php echo e($category->flowers->withQueryString()->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jk\Willy - WP\flowelto\resources\views/category.blade.php ENDPATH**/ ?>