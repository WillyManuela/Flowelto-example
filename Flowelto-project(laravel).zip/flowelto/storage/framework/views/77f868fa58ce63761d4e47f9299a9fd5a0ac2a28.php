

<?php $__env->startSection('main-content'); ?>
<div style="margin-left: 10%; margin-right:10%;margin-top: 2%">
    <div style="text-align: center">
        <label class="form-check-label pt-2 pb-3" style="font-size: 25px; font-weight: 600">Your Transaction History</label>
    </div>
    <div style=" margin-left:2%; margin-right: 2%">
        <?php $__currentLoopData = Auth::User()->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('transactiondetail',$t->id)); ?>" style="text-decoration: none; color: black">
                <div style="text-align: center; padding: 1%; background-color: #a97f81; margin-top:1%">
                    <label style="font-size:20px; font-weight: 600">Transaction at <?php echo e($t->date); ?></label>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <br><br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jk\Willy - WP\flowelto\resources\views/transactionhistory.blade.php ENDPATH**/ ?>