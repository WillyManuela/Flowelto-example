

<?php $__env->startSection('main-content'); ?>
<div style="height:40%; width:40%; margin-left: 30%; margin-top: 2%">
    <div style="text-align: center">
    <label class="form-check-label pt-2 pb-3" style="font-size: 20px">Change Password</label></div>
    <form style="padding:5px" action="<?php echo e(route('changepassword')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="bd-example" style="text-align: right">
        <?php if(session('false')): ?>
        <div class="text-danger"style="text-align: left; margin-left:35%">
            <?php echo e(session('false')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('true')): ?>
        <div class="text-success"style="text-align: center">
            <?php echo e(session('true')); ?>

        </div>
        <?php endif; ?>
        <div class="mb-3 row">
            <label class="col-sm-4 col-form-label">Your Password</label>
            <div class="col-sm-7">
              <input type="password" class="form-control" name="old">
            </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-4 col-form-label">New Password</label>
            <div class="col-sm-7">
              <input type="password" class="form-control" name="password">
            </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            <?php $__errorArgs = ['confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small style="color: red"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2 row">
            <label class="col-sm-4 col-form-label">Confirm Password</label>
            <div class="col-sm-7">
              <input type="password" class="form-control" name="confirm">
            </div>
          </div>
        </div>
        
        <button type="submit" class="btn btn-primary mb-4" style="margin-left:35%">Change Password</button>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WPprojectLab\flowelto\resources\views/changepassword.blade.php ENDPATH**/ ?>