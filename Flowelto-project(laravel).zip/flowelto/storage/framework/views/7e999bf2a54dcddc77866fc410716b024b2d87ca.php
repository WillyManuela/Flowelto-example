

<?php $__env->startSection('main-content'); ?>
<div style="margin-left: 10%; margin-right:10%;margin-top: 2%">
    <div style="text-align: center">
        <label class="form-check-label pt-2 pb-3" style="font-size: 20px">Your Cart</label>
    </div>
    <div style="margin-top: 5%; margin-left:2%; margin-right: 2%; background-color: #a97f81">
        <?php $__currentLoopData = Auth::User()->carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="display: flex; padding-left: 2%; padding-top: 2%">
                <div style="flex:1"><img src="<?php echo e(asset('assets/flower/'.$c->flower->img)); ?>" height="200px" width="200px"></div>
                <div style="flex:1; margin-top:5%; font-size:20px; margin-right:2%"><label><?php echo e($c->flower->name); ?></label></div>
                <div style="flex:2; margin-top:5%; display:flex">
                    <div class="mt-1"><label style="margin-left: 10%; width:100px">Rp. <?php echo e($c->flower->price * $c->quantity); ?></label></div>
                    <div style="margin-left:5%">
                        <form action="<?php echo e(route('updatecart',$c->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>
                            <label>Quantity</label>
                            <input type="number" class="col-sm-5" value="<?php echo e($c->quantity); ?>" name="quantity">
                        </div>
                        <div><button type="submit" href=""class="btn btn-primary" >Update</button></div>
                    </form>
                </div>
            </div><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if(Auth::User()->carts->count() == 0): ?> 
        <br><br>
    <?php else: ?>
        <div style="width: inherit; text-align: center; margin-top: 2%">
            <form action="<?php echo e(route('checkout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <button type="submit" class="btn btn-danger">Check Out</button>
            </form>
        </div>
    <?php endif; ?>
    <br><br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\jk\Willy - WP\flowelto\resources\views/mycart.blade.php ENDPATH**/ ?>