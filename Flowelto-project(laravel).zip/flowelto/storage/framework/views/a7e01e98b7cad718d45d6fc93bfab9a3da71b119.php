

<?php $__env->startSection('main-content'); ?>
    <div style="margin-left: 10%; margin-right: 10%; margin-top: 2%; display: flex">
        <div>
            <img src="<?php echo e(asset('assets/flower/'.$flower->img)); ?>" height="400px" width="400px">
        </div>
        <form action="<?php echo e(route('updateflower',$flower->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
            <div style="margin-left: 5%" >
                <div style="text-align: right">
                    <div style="text-align: left; margin-left:35%">
                        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: red"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 row">
                      <label class="col-sm-5 col-form-label">Category</label>
                      <div class="col-sm-7">
                        <select class="form-select form-control" aria-label=".form-select-lg example" name="category">
                            <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($c->id); ?>" name="category" <?php if($c->id == $flower->id): ?> selected <?php endif; ?>><?php echo e($c->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <div style="text-align: left; margin-left:35%">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: red"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 row" >
                        <label class="col-sm-5 col-form-label">Flower Name</label>
                        <div class="col-sm-7" >
                        <input type="text" class="form-control" name="name" value="<?php echo e($flower->name); ?>">
                        </div>
                    </div>
                    <div style="text-align: left; margin-left:35%">
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: red"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 row" >
                        <label class="col-sm-5 col-form-label">Flower Price (Rupiah)</label>
                        <div class="col-sm-7" >
                        <input type="text" class="form-control" name="price" value="<?php echo e($flower->price); ?>">
                        </div>
                    </div>
                    <div style="text-align: left; margin-left:35%">
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: red"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 row" >
                        <label class="col-sm-5 col-form-label">Flower Description</label>
                        <div class="col-sm-7" >
                        <input type="text" class="form-control" name="description" value="<?php echo e($flower->description); ?>">
                        </div>
                    </div>
                    <div style="text-align: left; margin-left:35%">
                        <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color: red"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-5 col-form-label">Flower Image</label>
                        <div class="col-sm-7">
                        <input type="file" class="form-control" name="img" value="<?php echo e(old('img')); ?>">
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary mb-4 mr-4" style="margin-left:35%">Update</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WPprojectLab\flowelto\resources\views/updateflower.blade.php ENDPATH**/ ?>