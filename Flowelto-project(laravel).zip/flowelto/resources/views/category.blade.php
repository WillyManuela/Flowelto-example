@extends('main')

@section('main-content')
<div style="margin-left: 10%; margin-top:1%; margin-right: 10%; margin-bottom:2%">
    <div style="text-align: center">
        <label style="font-size: 35px; font-style: italic; font-weight: 500">Our {{$category->name}}</label><br>
    </div>
    <div >
        <form action="{{route('category',$category->id)}}">
            @csrf
            <div class="col-sm-12" style="display:flex">
                <div style="margin-right:1%">
                <select class="form-select mb-3 form-control" aria-label=".form-select-lg example" name="select">
                    <option value="name" name="select">Name</option>
                    <option value="price" name="select">Price</option>
                </select></div>
                <div><input type="text" class="form-control" name="search" placeholder="Search"  value="{{ Request::input('search') }}"></div>
                <div style="margin-left:2%"><button type="submit" class="btn btn-primary">Search</button></div>
            </div>
        </form>
    </div>
    <div>
        <div class="row row-cols-2 row-cols-md-4 mt-3 ml-2">
            @foreach ($category->flowers as $f)
                <a href="{{route('detail',$f->id)}}" style="text-decoration: none; color: black">
                    <div class="col mb-4 mr-2">
                        <div class="card" style="background-color: #fe80bf; text-align: center">
                            <img src="{{asset('assets/flower/'.$f->img)}}" class="card-img-top" height="350px" width="350px" style="padding:2%">
                            <div class="card-body">
                                <label>{{$f->name}}</label><br>
                                <label>Rp. {{$f->price}}</label>
                            </div>
                            @if(Auth::User() && Auth::User()->role->name == 'Manager')
                            <div class="mb-2"style="display: flex; margin-left:3.5%">
                                <div>
                                    <form action="{{route('deleteflower',$f->id)}}" method="POST">
                                        @csrf
                                        @method('POST')
                                        <button type="submit" class="btn btn-danger">Delete Flower</button>
                                    </form>
                                </div>
                                <div style="margin-left: 5%">
                                    <form action="{{route('updateflower',$f->id)}}">
                                        @csrf
                                        <button type="submit" class="btn btn-primary">Update Flower</button>
                                    </form>
                                </div>
                            </div>
                            @endif
                        </div>
                    </div>
                </a>
            @endforeach
        </div>
        <div style="margin-left:45%"> 
            {{$category->flowers->withQueryString()->links()}}
        </div>
    </div>
</div>
@endsection