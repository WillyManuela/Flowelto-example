@extends('main')

@section('main-content')
<div style="margin-left: 10%; margin-right:10%;margin-top: 2%">
    <div style="text-align: center">
        <label class="form-check-label pt-2 pb-3" style="font-size: 20px">Your Cart</label>
    </div>
    <div style="margin-top: 5%; margin-left:2%; margin-right: 2%; background-color: #a97f81">
        @foreach(Auth::User()->carts as $c)
            <div style="display: flex; padding-left: 2%; padding-top: 2%">
                <div style="flex:1"><img src="{{asset('assets/flower/'.$c->flower->img)}}" height="200px" width="200px"></div>
                <div style="flex:1; margin-top:5%; font-size:20px; margin-right:2%"><label>{{$c->flower->name}}</label></div>
                <div style="flex:2; margin-top:5%; display:flex">
                    <div class="mt-1"><label style="margin-left: 10%; width:100px">Rp. {{$c->flower->price * $c->quantity}}</label></div>
                    <div style="margin-left:5%">
                        <form action="{{route('updatecart',$c->id)}}" method="POST">
                            @csrf
                            @method('POST')
                            <label>Quantity</label>
                            <input type="number" class="col-sm-5" value="{{$c->quantity}}" name="quantity">
                        </div>
                        <div><button type="submit" href=""class="btn btn-primary" >Update</button></div>
                    </form>
                </div>
            </div><br>
        @endforeach
    </div>
    @if(Auth::User()->carts->count() == 0) 
        <br><br>
    @else
        <div style="width: inherit; text-align: center; margin-top: 2%">
            <form action="{{route('checkout')}}" method="POST">
                @csrf
                @method('POST')
                <button type="submit" class="btn btn-danger">Check Out</button>
            </form>
        </div>
    @endif
    <br><br>
</div>
@endsection