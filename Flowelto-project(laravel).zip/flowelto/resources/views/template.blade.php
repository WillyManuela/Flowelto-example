@extends('main')

@section('main-content')
    Hello World
@endsection