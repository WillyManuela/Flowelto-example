<nav class="navbar navbar-expand-lg navbar-light" style="padding: 0.5%; background-color: #ed0c82">
    <div class="container-fluid" >
      <a class="navbar-brand font-typo" href="/" style="margin-left: 10%"><label>Flowelto Shop</label></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <form class="d-flex" style="margin-right: 5%" >
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Categories
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    @foreach (App\Category::all() as $c)
                        <li><a class="dropdown-item" href="{{route('category',$c->id)}}">{{$c->name}}</a></li>
                    @endforeach
                </ul>
            </li>
        @if(!Auth::User())
            <li class="nav-item">
                <a class="nav-link mr-4" href="{{route('login')}}">Login</a>
            </li>
            <li class="nav-item">
                <a class="nav-link mr-4" href="{{route('register')}}">Register</a>
            </li>
        @else
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    {{Auth::User()->username}}
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    @if(Auth::User()->role->name == 'Manager')
                        <li><a class="dropdown-item" href="{{route('addflower')}}">Add Flower</a></li>
                        <li><a class="dropdown-item" href="{{route('managecategory')}}">Manage Categories</a></li>
                    @else
                        <li><a class="dropdown-item" href="{{route('mycart')}}">My Cart</a></li>
                        <li><a class="dropdown-item" href="{{route('transactionhistory')}}">Transaction History</a></li>
                    @endif
                    <li><a class="dropdown-item" href="{{route('changepassword')}}">Change Password</a></li>
                    <li><a class="dropdown-item" href="{{route('logout')}}">Logout</a></li>
                </ul>
            </li>
        @endif
        <li class="nav-item">
            <label class="nav-link mr-4">{{ now()->format('D, d M Y') }}</label>
        </li>
        </ul>
        </div>
    </form>
    </div>

  </nav>