@extends('main')

@section('main-content')
<div style="height:40%; width:40%; margin-left: 30%; margin-top: 2%">
    <div style="text-align: center">
    <label class="form-check-label pt-2 pb-3" style="font-size: 20px">Register</label></div>
    <form style="padding:5px" action="{{route('register')}}" method="POST">
    @csrf
    <div class="bd-example" style="text-align: right">
        <div style="text-align: left; margin-left:35%">
            @error('username')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-3 row">
          <label class="col-sm-4 col-form-label">Username</label>
          <div class="col-sm-7">
            <input type="text" class="form-control" name="username" value="{{old('username')}}">
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            @error('email')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-3 row">
            <label class="col-sm-4 col-form-label">E-mail Address</label>
            <div class="col-sm-7">
              <input type="email" class="form-control" name="email" value="{{old('email')}}">
            </div>
          </div>
        <div style="text-align: left; margin-left:35%">
            @error('password')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-3 row">
            <label class="col-sm-4 col-form-label">Password</label>
            <div class="col-sm-7">
              <input type="password" class="form-control" name="password">
            </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            @error('confirm')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-2 row">
            <label class="col-sm-4 col-form-label">Confirm Password</label>
            <div class="col-sm-7">
              <input type="password" class="form-control" name="confirm">
            </div>
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            @error('gender')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <fieldset class="form-group ">
            <div class="mb-3 row">
                <legend class="col-sm-4 col-form-label" style="text-align: right">Gender</legend>
                <div class="col-sm-3">
                    <input class="form-check-input mt-2" type="radio" name="gender" value="Male">
                    <label class="col-sm-4 col-form-label">Male</label>
                </div>
                <div class="col-sm-3">
                    <input class="form-check-input mt-2" type="radio" name="gender" value="Female">
                    <label class="col-sm-4 col-form-label">Female</label>
                </div>
            </div>
        </fieldset>
        <div style="text-align: left; margin-left:35%">
            @error('dob')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-3 row" style="text-align: right">
          <label class="col-sm-4 col-form-label">Date Of Birth</label>
          <div class="col-sm-7">
            <input type="date" class="form-control" name="dob" value="{{old('dob')}}">
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            @error('address')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-3 row" style="text-align: right">
          <label class="col-sm-4 col-form-label">Address</label>
          <div class="col-sm-7">
            <textarea  class="form-control" name="address" value="{{old('address')}}"></textarea>
          </div>
        </div>
        <button type="submit" class="btn btn-primary mb-4" style="margin-left:35%">Register</button>
    </div>
</form>
</div>
@endsection