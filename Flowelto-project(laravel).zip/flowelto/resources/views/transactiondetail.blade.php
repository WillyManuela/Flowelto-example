@extends('main')

@section('main-content')
<div style="margin-left: 10%; margin-right:10%;margin-top: 2%">
    <div style="text-align: center">
        <label class="form-check-label pt-2 pb-3" style="font-size: 25px; font-weight: 600">Your Transaction at {{$transaction->date}}</label>
    </div>
    <div style=" margin-left:2%; margin-right: 2%; text-align: right">
        <table class="table" style="background-color: #a97f81; text-align:center">
            <thead>
              <tr>
                <th scope="col">Flower Image</th>
                <th scope="col">Flower Name</th>
                <th scope="col">Subtotal</th>
                <th scope="col">Quantity</th>
              </tr>
            </thead>
            <?php $total = 0; ?>
            <tbody>
                @foreach($transaction->transactiondetails as $td)
                    <tr>
                        <td><img src="{{asset('assets/flower/'.$td->flower->img)}}" width="150px" height="150px"></td>
                        <td>{{$td->flower->name}}</td>
                        <td>{{$td->flower->price * $td->quantity}}</td>
                        <td>{{$td->quantity}}</td>
                    </tr>
                    <?php $total = $total + $td->quantity * $td->flower->price; ?>
                @endforeach
            </tbody>
          </table>
          <label style="width: inherit; font-weight: 600">Total Price: Rp {{$total}}</label>
    </div>
    <br><br>
</div>
@endsection