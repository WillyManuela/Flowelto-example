@extends('main')

@section('main-content')
<div style="margin-left: 10%; margin-top:1%; margin-right: 10%; margin-bottom:2%">
    <div style="text-align: center">
        <label style="font-size: 35px; font-style: italic; font-weight: 500">Welcome to Flowelto Shop</label><br>
        <label style="font-size: 25px; font-weight: 500">The Best Flower Shop in Binus University</label>
    </div>
    <div>
        <div class="row row-cols-2 row-cols-md-2 mt-3 ml-2" style="margin-left: 19%;margin-right: 19%">
            @foreach ($categories as $c)
                <a href="{{route('category',$c->id)}}" style="text-decoration: none; color: black">
                    <div class="col mb-4 mr-2">
                        <div class="card" style="background-color: #fe80bf; text-align: center">
                            <img src="{{asset('assets/category/'.$c->img)}}"  height="350px" width="350px" style="padding:2%">
                            <div class="card-body">
                                <h4 class="card-title">{{$c->name}}</h4>
                            </div>
                        </div>
                    </div>
                </a>
            @endforeach
        </div>
    </div>
</div>
@endsection