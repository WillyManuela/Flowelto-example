@extends('main')

@section('main-content')
<div style="height:40%; width:40%; margin-left: 30%; margin-top: 2%">
    <div style="text-align: center">
    <label class="form-check-label pt-2 pb-3" style="font-size: 20px">Change Password</label></div>
    <form style="padding:5px" action="{{route('changepassword')}}" method="POST">
    @csrf
    <div class="bd-example" style="text-align: right">
        @if(session('false'))
        <div class="text-danger"style="text-align: left; margin-left:35%">
            {{session('false')}}
        </div>
        @endif
        @if(session('true'))
        <div class="text-success"style="text-align: center">
            {{session('true')}}
        </div>
        @endif
        <div class="mb-3 row">
            <label class="col-sm-4 col-form-label">Your Password</label>
            <div class="col-sm-7">
              <input type="password" class="form-control" name="old">
            </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            @error('password')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-3 row">
            <label class="col-sm-4 col-form-label">New Password</label>
            <div class="col-sm-7">
              <input type="password" class="form-control" name="password">
            </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            @error('confirm')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-2 row">
            <label class="col-sm-4 col-form-label">Confirm Password</label>
            <div class="col-sm-7">
              <input type="password" class="form-control" name="confirm">
            </div>
          </div>
        </div>
        
        <button type="submit" class="btn btn-primary mb-4" style="margin-left:35%">Change Password</button>
    </div>
</form>
</div>
@endsection