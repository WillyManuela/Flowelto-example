@extends('main')

@section('main-content')
    <div style="margin-left: 10%; margin-right: 10%; margin-top: 2%; display: flex">
        <div>
            <img src="{{asset('assets/flower/'.$flower->img)}}" height="400px" width="400px">
        </div>
        <form action="{{route('updateflower',$flower->id)}}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('POST')
            <div style="margin-left: 5%" >
                <div style="text-align: right">
                    <div style="text-align: left; margin-left:35%">
                        @error('category')
                        <small style="color: red">{{$message}}</small>
                        @enderror
                    </div>
                    <div class="mb-3 row">
                      <label class="col-sm-5 col-form-label">Category</label>
                      <div class="col-sm-7">
                        <select class="form-select form-control" aria-label=".form-select-lg example" name="category">
                            @foreach (App\Category::all() as $c)
                                <option value="{{$c->id}}" name="category" @if($c->id == $flower->id) selected @endif>{{$c->name}}</option>
                            @endforeach
                        </select>
                      </div>
                    </div>
                    <div style="text-align: left; margin-left:35%">
                        @error('name')
                        <small style="color: red">{{$message}}</small>
                        @enderror
                    </div>
                    <div class="mb-3 row" >
                        <label class="col-sm-5 col-form-label">Flower Name</label>
                        <div class="col-sm-7" >
                        <input type="text" class="form-control" name="name" value="{{$flower->name}}">
                        </div>
                    </div>
                    <div style="text-align: left; margin-left:35%">
                        @error('price')
                        <small style="color: red">{{$message}}</small>
                        @enderror
                    </div>
                    <div class="mb-3 row" >
                        <label class="col-sm-5 col-form-label">Flower Price (Rupiah)</label>
                        <div class="col-sm-7" >
                        <input type="text" class="form-control" name="price" value="{{$flower->price}}">
                        </div>
                    </div>
                    <div style="text-align: left; margin-left:35%">
                        @error('description')
                        <small style="color: red">{{$message}}</small>
                        @enderror
                    </div>
                    <div class="mb-3 row" >
                        <label class="col-sm-5 col-form-label">Flower Description</label>
                        <div class="col-sm-7" >
                        <input type="text" class="form-control" name="description" value="{{$flower->description}}">
                        </div>
                    </div>
                    <div style="text-align: left; margin-left:35%">
                        @error('img')
                        <small style="color: red">{{$message}}</small>
                        @enderror
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-5 col-form-label">Flower Image</label>
                        <div class="col-sm-7">
                        <input type="file" class="form-control" name="img" value="{{old('img')}}">
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary mb-4 mr-4" style="margin-left:35%">Update</button>
            </div>
        </form>
    </div>
@endsection