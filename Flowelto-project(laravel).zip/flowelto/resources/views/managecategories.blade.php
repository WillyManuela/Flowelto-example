@extends('main')

@section('main-content')
<div style="margin-left: 10%; margin-top:1%; margin-right: 10%; margin-bottom:2%">
    <div style="text-align: center">
        <label style="font-size: 35px; font-style: italic; font-weight: 500">Manage Category</label><br>
    </div>
    <div>
        <div class="row row-cols-2 row-cols-md-3 mt-3 ml-2">
            @foreach ($categories as $c)
                <div class="col mb-4 mr-2">
                    <div class="card" style="background-color: #fe80bf; text-align: center">
                        <img src="{{asset('assets/category/'.$c->img)}}" class="card-img-top" height="350px" width="350px" style="padding:2%">
                        <div class="card-body">
                            <label>{{$c->name}}</label><br>
                        </div>
                        <div class="mb-2"style="display: flex; margin-left:3.5%">
                            <div style="margin-left: 10%">
                                <form action="{{route('deletecategory',$c->id)}}" method="POST">
                                    @csrf
                                    @method('POST')
                                    <button type="submit" class="btn btn-danger">Delete Category</button>
                                </form>
                            </div>
                            <div style="margin-left: 1%">
                                <a href="{{route('updatecategory',$c->id)}}" class="btn btn-primary">Update Category</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
@endsection