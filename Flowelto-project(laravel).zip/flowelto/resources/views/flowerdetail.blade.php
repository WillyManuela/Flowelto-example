@extends('main')

@section('main-content')
    <div style="margin-left: 10%; margin-right: 10%; margin-top: 2%; display: flex">
        <div>
            <img src="{{asset('assets/flower/'.$flower->img)}}" height="500px" width="500px">
        </div>
        <div style="margin-left: 10%">
            <label style="font-size: 32px; font-weight: 550">{{$flower->name}}</label><br>
            <label class="mt-2" style="font-size: 28px; font-weight: 450">Rp {{$flower->price}}</label><br>
            <label class="mt-2" style="font-size: 20px">{{$flower->description}}</label>
            @if(!(Auth::User() && Auth::User()->role->name == 'Manager'))
            <form action="{{route('addtocart',$flower->id)}}" method="POST">
                @csrf
                @method('post')
                <div style="margin-top: 20px">
                    @error('quantity')
                    <p class="text-danger">{{$message}}</p>
                    @enderror
                    <div style="display: flex">
                        <div><label for="staticEmail" class="col-form-label">Quantity :</label></div>
                        <div class="col-sm-15" style="margin-left: 15px">
                        <input class="form-control"type="number" name="quantity" value="{{ old('quantity') }}"></div>
                    </div>
                    <button class="btn btn-primary" type="submit" style="margin-top: 20px; margin-left: 80px">Add To Cart</button>
                </div>
            </form>
            @endif
        </div>
    </div>
@endsection