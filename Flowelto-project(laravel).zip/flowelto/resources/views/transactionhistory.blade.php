@extends('main')

@section('main-content')
<div style="margin-left: 10%; margin-right:10%;margin-top: 2%">
    <div style="text-align: center">
        <label class="form-check-label pt-2 pb-3" style="font-size: 25px; font-weight: 600">Your Transaction History</label>
    </div>
    <div style=" margin-left:2%; margin-right: 2%">
        @foreach(Auth::User()->transactions as $t)
            <a href="{{route('transactiondetail',$t->id)}}" style="text-decoration: none; color: black">
                <div style="text-align: center; padding: 1%; background-color: #a97f81; margin-top:1%">
                    <label style="font-size:20px; font-weight: 600">Transaction at {{$t->date}}</label>
                </div>
            </a>
        @endforeach
    </div>
    <br><br>
</div>
@endsection