@extends('main')

@section('main-content')
<div style="height:40%; width:40%; margin-left: 30%; margin-top: 2%">
    <div style="text-align: center">
    <label class="form-check-label pt-2 pb-3" style="font-size: 20px">Add Flower</label></div>
    @if (session('success'))
    <div style="text-align: center; margin-bottom:2%">
    <label class="text-success">
        {{session('success')}}
    </label></div>
    @endif
    <form style="padding:5px" action="{{route('addflower')}}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="bd-example" style="text-align: right">
        <div style="text-align: left; margin-left:35%">
            @error('category')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-3 row">
          <label class="col-sm-4 col-form-label">Category</label>
          <div class="col-sm-7">
            <select class="form-select form-control" aria-label=".form-select-lg example" name="category">
                @foreach (App\Category::all() as $c)
                    <option value="{{$c->id}}" name="category">{{$c->name}}</option>
                @endforeach
            </select>
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            @error('name')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-3 row">
            <label class="col-sm-4 col-form-label">Flower Name</label>
            <div class="col-sm-7">
              <input type="text" class="form-control" name="name" value="{{old('name')}}">
            </div>
          </div>
        <div style="text-align: left; margin-left:35%">
            @error('price')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-3 row" style="text-align: right">
          <label class="col-sm-4 col-form-label">Flower Price (Rupiah)</label>
          <div class="col-sm-7">
            <input type="number" class="form-control" name="price" value="{{old('price')}}">
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            @error('description')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-3 row" style="text-align: right">
          <label class="col-sm-4 col-form-label">Description</label>
          <div class="col-sm-7">
            <textarea  class="form-control" name="description" value="{{old('description')}}"></textarea>
          </div>
        </div>
        <div style="text-align: left; margin-left:35%">
            @error('img')
            <small style="color: red">{{$message}}</small>
            @enderror
        </div>
        <div class="mb-3 row">
            <div class="col-sm-1"></div>
            <label for="staticEmail" class="col-sm-3 col-form-label">Flower Image</label>
            <div class="col-sm-7">
              <input type="file" class="form-control" name="img" value="{{old('img')}}">
            </div>
        </div>
    </div>
    <button type="submit" class="btn btn-primary mb-4 mr-4" style="margin-left:35%">Add</button>
</form>
</div>
@endsection