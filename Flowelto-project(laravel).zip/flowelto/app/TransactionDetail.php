<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransactionDetail extends Model
{
    public $timestamps = false;
    protected $table = 'transactiondetails';

    protected $fillable = [
        'transaction_id', 'flower_id', 'quantity'
    ];

    public function flower(){
        return $this->belongsTo(Flower::class,'flower_id');
    }
}
