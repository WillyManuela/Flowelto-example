<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Flower extends Model
{
    public $timestamps = false;
    protected $table = 'flowers';

    protected $fillable = [
        'name', 'description', 'img','category_id', 'price'
    ];

    public function category(){
        return $this->belongsTo(Category::class,'category_id');
    }
}
