<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    public $timestamps = false;
    protected $table = 'carts';

    protected $fillable = [
        'flower_id', 'user_id', 'quantity',
    ];

    public function flower(){
        return $this->belongsTo(Flower::class,'flower_id');
    }

}
