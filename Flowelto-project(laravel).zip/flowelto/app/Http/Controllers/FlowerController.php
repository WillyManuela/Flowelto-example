<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Flower;

class FlowerController extends Controller
{
    public function add(Request $request){
        $this->_validation($request);
        $img = $request->file('img');
        $flower = Flower::create([
            'category_id' => $request->category,
            'name' => $request->name,
            'description' => $request->description,
            'price' => $request->price,
            'img' => $img->getClientOriginalName(),

        ]);
        $img->move('assets/flower',$img->getClientOriginalName());
        return redirect()->route('addflower')->with('success','Success add flower');
    }

    public function delete($id){
        $flower = Flower::find($id);
        $c_id = $flower->category_id;
        $flower->delete();
        return redirect()->route('category',$c_id);
    }

    public function update(Request $request, $id){
        $this->_validationUpdate($request);

        $flower = Flower::find($id);
        $flower->price = $request->price;
        $flower->description = $request->description;
        $flower->category_id = $request->category;
        $flower->name = $request->name;
        $img = $request->file('img');
        if($img){
            $flower->img = $img->getClientOriginalName();
            $img->move('assets/flower',$img->getClientOriginalName());
        }
        $flower->save();

        return redirect()->route('updateflower',$id);
    }

    public function _validationUpdate(Request $request){
        $validation = $request->validate([
            'category'  => 'required',
            'name'  => 'required|min:5',
            'price'  => 'required|gte:50000|numeric',
            'img' => 'nullable|mimes:jpg,png,jpeg',
            'description' => 'required|min:20'
            ],
            [
            'required' => 'Must be filled',
            'name.min' => 'Minimum 5 characters',
            'description.min' => 'Minimum 20 characters',
            'price.numeric' => 'Must be a number',
            'price.gte' => 'Must more than or equal to 50000',
            'mimes' => 'Must be jpg,png,jpeg'
            ]
        );
    }

    public function _validation(Request $request){
        $validation = $request->validate([
            'category'  => 'required',
            'name'  => 'required|min:5',
            'price'  => 'required|gte:50000|numeric',
            'img' => 'required|mimes:jpg,png,jpeg',
            'description' => 'required|min:20'
            ],
            [
            'required' => 'Must be filled',
            'name.min' => 'Minimum 5 characters',
            'description.min' => 'Minimum 20 characters',
            'price.numeric' => 'Must be a number',
            'price.gte' => 'Must more than or equal to 50000',
            'mimes' => 'Must be jpg,png,jpeg'
            ]
        );
    }
}
