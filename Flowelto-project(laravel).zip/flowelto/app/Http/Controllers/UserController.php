<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Cookie;
use App\User;

class UserController extends Controller
{
    public function login(Request $request){
        if(Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            if($request->rememberMe) {
                return redirect('/')->withCookie(Cookie::make('email', $request->email,10080));
            }
            return redirect('/');
        }
        return redirect('login')->with('wrong','Wrong Email or Password');
    }

    public function logout(Request $request){
        $request->session()->flush();
        return redirect('/');
    }

    public function register(Request $request){
        $this->_registerValidation($request);
        $user = User::create([
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'email' => $request->email,
            'gender' => $request->gender,
            'dob' => $request->dob,
            'address' => $request->address,
            'role_id' => 2,
        ]);
        return redirect('login');
    }

    public function changePassword(Request $request){
        if(Hash::check($request->old, Auth::User()->password)){
            $this->_changePassValidation($request);
            $user = Auth::User();
            $user->password = Hash::make($request->password);
            $user->save();
            return redirect()->route('changepassword')->with('true','Success Change Password');
        }
        else{
            return redirect()->route('changepassword')->with('false','Wrong Password');
        }
    }

    private function _changePassValidation(Request $request){
        $validation = $request->validate(
            [
                'password'  => 'required|min:8',
                'confirm'  => 'required|required_with:password|same:password',
            ],
            [
                'required'  => 'Must be filled',
                'confirm.required_with'  => 'Must be same as password',
                'confirm.same'  => 'Must be same as password',
            ],
        );
    }

    private function _registerValidation(Request $request){
        $validation = $request->validate(
            [
                'username'  => 'required|min:5',
                'email'  => 'required|unique:users',
                'password'  => 'required|min:8',
                'confirm'  => 'required|required_with:password|same:password',
                'gender' => 'required',
                'dob'  => 'required',
                'address'  => 'required|min:10',
            ],
            [
                'username.required'  => 'Must be filled',
                'email.required'  => 'Must be filled',
                'password.required'  => 'Must be filled',
                'confirm.required'  => 'Must be filled',
                'gender.required' => 'Must be filled',
                'dob.required'  => 'Must be filled',
                'address.required'  => 'Must be filled',
                'username.min'  => 'Minimum 5 Characters',
                'password.min'  => 'Minimum 8 Characters',
                'address.min'  => 'Minimum 10 Characters',
                'email.unique'  => 'Email has been taken',
                'confirm.required_with'  => 'Must be same as password',
                'confirm.same'  => 'Must be same as password',
            ],
        );
    }
}
