<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Category;
use App\Flower;
use App\Transaction;

class MainController extends Controller
{
    public function home(){
        $categories = Category::all();
        return view('home', compact('categories'));
    }

    public function login(){
        return view('login');
    }

    public function register(){
        return view('register');
    }

    public function category(Request $request, $id){
        $category = Category::find($id);
        $category->flowers = Flower::Where('category_id',$id)->paginate(8);
        $search = $request->input('search');
        if($request->select == 'price'){
            $category->flowers = Flower::Where('category_id',$id)->where('price', $search)->paginate(8);
        }else{
            $category->flowers = Flower::Where('category_id',$id)->where('name', 'like', "%$search%")->paginate(8);
        }
        return view('category',compact('category'));
    }

    public function flowerDetail($id){
        $flower = Flower::find($id);
        return view('flowerdetail',compact('flower'));
    }

    public function addFlower(){
        if(Auth::User() && Auth::User()->role->name != 'Manager') {
            return redirect('/');
        }
        return view('addflower');
    }

    public function manageCategory(){
        if(Auth::User() && Auth::User()->role->name != 'Manager') {
            return redirect('/');
        }
        $categories = Category::all();
        return view('managecategories',compact('categories'));
    }

    public function updateCategory($id){
        if(Auth::User() && Auth::User()->role->name != 'Manager') {
            return redirect('/');
        }
        $category = Category::find($id);
        return view('updatecategory',compact('category'));
    }

    public function myCart(){
        if(Auth::User() && Auth::User()->role->name != 'Customer') {
            return redirect('/');
        }
        return view('mycart');
    }

    public function transactionHistory(){
        if(Auth::User() && Auth::User()->role->name != 'Customer') {
            return redirect('/');
        }
        return view('transactionhistory');
    }

    public function transactionDetail($id){
        if(Auth::User() && Auth::User()->role->name != 'Customer') {
            return redirect('/');
        }
        $transaction = Transaction::find($id);
        return view('transactiondetail',compact('transaction'));
    }

    public function updateFlower($id){
        if(Auth::User() && Auth::User()->role->name != 'Manager') {
            return redirect('/');
        }
        $flower = Flower::find($id);
        return view('updateflower',compact('flower'));
    }

    public function changePassword(){
        if(!Auth::User()) {
            return redirect('/');
        }
        return view('changepassword');
    }

}
