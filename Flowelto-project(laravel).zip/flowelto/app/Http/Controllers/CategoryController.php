<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class CategoryController extends Controller
{
    public function delete($id){
        $category = Category::find($id);
        $category->delete();
        return redirect()->route('managecategory');
    }

    public function update(Request $request, $id){
        $this->_validate($request);
        $category = Category::find($id);
        $category->name = $request->name;
        $img = $request->file('img');
        if($img){
            $category->img = $img->getClientOriginalName();
            $img->move('assets/category',$img->getClientOriginalName());
        }
        $category->save();
        return redirect()->route('updatecategory',$id);
    }

    private function _validate(Request $request){
        $validation = $request->validate([
            'name'  => 'required|min:5|unique:categories',
            'img' => 'nullable|mimes:jpg,png,jpeg',
            ],
            [
            'required' => 'Must be filled',
            'name.min' => 'Minimum 5 characters',
            'unique' => 'Category name already exists',
            'mimes' => 'Must be jpg,png,jpeg'
            ]
        );
    }

}
