<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Cart;
use App\Transaction;
use App\TransactionDetail;

class CartController extends Controller
{
    public function add(Request $request, $id){
        if(!Auth::User()) return redirect()->route('login');
        $this->_validate($request);
        $c = Cart::Where('flower_id',$id)->where('user_id',Auth::id())->first();
        if($c != null){
            $c->quantity = $c->quantity + $request->quantity;
            $c->update();
        }else{
            $cart = Cart::create([
                'flower_id' => $id,
                'user_id' => Auth::id(),
                'quantity' => $request->quantity,
            ]);
        }
        return redirect('/');
    }

    public function update(Request $request, $id){
        $this->_validate($request);
        $c = Cart::find($id);
        if($request->quantity > 0){
            $c->quantity = $request->quantity;
            $c->update();
        }else{
            $c->delete();
        }
        return redirect()->route('mycart');
    }

    public function checkout(){
        $carts = Cart::Where('user_id',Auth::id())->get();
        $transaction = Transaction::create([
            'date' => now(),
            'user_id' => Auth::id(),
        ]);

        foreach($carts as $c){
            $transactiondetail = TransactionDetail::create([
                'flower_id' => $c->flower_id,
                'transaction_id' => $transaction->id,
                'quantity' => $c->quantity,
            ]);
            $c->delete();
        }
        
        return redirect()->route('transactionhistory');
    }

    private function _validate(Request $request){
        $validation = $request->validate([
            'quantity'  => 'required|numeric|min:0',
        ],
        [
            'quantity.required'  => 'Must be filled',
            'quantity.numeric'  => 'Must be numeric',
            'quantity.min'  => 'Quantity must be at least 1',
        ]
        );
    }
}
