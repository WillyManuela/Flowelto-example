<?php

use Illuminate\Database\Seeder;

class CategoriesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert(array(
            array(
                'name' => 'Hand bouquet (gift)',
                'img' => 'bouquet.jpg',
            ),
            array(
                'name' => 'Fleur Box',
                'img' => 'fleurbox.jpg',
            ),
            array(
                'name' => 'Fresh Flowers',
                'img' => 'freshflower.jpg',
            ),
            array(
                'name' => 'Blossom Box',
                'img' => 'blossombox.jpg',
            ),
        ));
    }
}
