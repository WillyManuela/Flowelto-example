<?php

use Illuminate\Database\Seeder;

class TransactionDetailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('transactiondetails')->insert(array(
            array(
                'transaction_id' => '1',
                'flower_id' => '2',
                'quantity' => '1',
            ),
            array(
                'transaction_id' => '1',
                'flower_id' => '15',
                'quantity' => '2',
            ),
        ));
    }
}
