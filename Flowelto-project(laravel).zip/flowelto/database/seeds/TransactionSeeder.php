<?php

use Illuminate\Database\Seeder;

class TransactionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('transactions')->insert(array(
            array(
                'user_id' => '2',
                'date' => '2020-11-20 19:30:28',
            ),
        ));
    }
}
