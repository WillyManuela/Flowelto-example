<?php

use Illuminate\Database\Seeder;

class FlowersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('flowers')->insert(array(
            array(
                'name' => 'Watermelon Snow',
                'description' => 'Favourite Bouquet Flower',
                'price' => 1500000,
                'img' => 'watermelonsnow.jpg',
                'category_id' => 1,
            ),
            array(
                'name' => 'Sunflower Burst',
                'description' => 'Favourite Bouquet Flower',
                'price' => 950000,
                'img' => 'sunflowerburst.jpg',
                'category_id' => 1,
            ),
            array(
                'name' => 'Sweet Cotton Candy',
                'description' => 'Favourite Bouquet Flower',
                'price' => 950000,
                'img' => 'cottoncandy.jpg',
                'category_id' => 1,
            ),
            array(
                'name' => 'Twilight And Sunset',
                'description' => 'Favourite Bouquet Flower',
                'price' => 2000000,
                'img' => 'twilightnsunset.jpg',
                'category_id' => 1,
            ),
            array(
                'name' => 'Romantic Day in Blausee',
                'description' => 'Favourite Bouquet Flower',
                'price' => 1800000,
                'img' => 'romanticday.jpg',
                'category_id' => 1,
            ),
            array(
                'name' => 'Pink Gerbera Daisy',
                'description' => 'Favourite Bouquet Flower',
                'price' => 380000,
                'img' => 'pinkgerbera.jpg',
                'category_id' => 1,
            ),
            array(
                'name' => 'Famouse Rosaline Bouquet',
                'description' => 'Favourite Bouquet Flower',
                'price' => 2200000,
                'img' => 'rosalina.jpg',
                'category_id' => 1,
            ),
            array(
                'name' => 'Petite Red Baby Breath',
                'description' => 'Favourite Bouquet Flower',
                'price' => 650000,
                'img' => 'petitered.jpg',
                'category_id' => 1,
            ),
            array(
                'name' => 'Petite Yellow Baby Breath',
                'description' => 'Favourite Bouquet Flower',
                'price' => 650000,
                'img' => 'yellowbabybreath.jpg',
                'category_id' => 1,
            ),
            array(
                'name' => 'Turqoise Blue Baby Breath',
                'description' => 'Favourite Bouquet Flower',
                'price' => 650000,
                'img' => 'turqoisebabybreath.jpg',
                'category_id' => 1,
            ),
            array(
                'name' => 'Simple Sparkling Gold',
                'description' => 'Favourite Bouquet Flower',
                'price' => 480000,
                'img' => 'simplesparklinggold.jpg',
                'category_id' => 1,
            ),
            array(
                'name' => 'Merry Cup-Mast',
                'description' => 'Favourite Fleur Box Flower',
                'price' => 550000,
                'img' => 'merrycup.jpg',
                'category_id' => 2,
            ),
            array(
                'name' => 'Cup of Festive',
                'description' => 'Favourite Fleur Box Flower',
                'price' => 850000,
                'img' => 'festive.jpg',
                'category_id' => 2,
            ),
            array(
                'name' => 'Aera Fleur Bloom Box',
                'description' => 'Favourite Fleur Box Flower',
                'price' => 1000000,
                'img' => 'aerafleur.jpg',
                'category_id' => 2,
            ),
            array(
                'name' => 'Chloe Sharing Box',
                'description' => 'Favourite Fleur Box Flower',
                'price' => 500000,
                'img' => 'chloe.jpg',
                'category_id' => 2,
            ),
            array(
                'name' => 'Magical Blue Majesty',
                'description' => 'Favourite Fresh Flower',
                'price' => 2000000,
                'img' => 'magicalblue.jpg',
                'category_id' => 3,
            ),
            array(
                'name' => 'Pink Elena',
                'description' => 'Favourite Fresh Flower',
                'price' => 555000,
                'img' => 'pinkelena.jpg',
                'category_id' => 3,
            ),
            array(
                'name' => 'Dreamy Luxurious Red',
                'description' => 'Favourite Fresh Flower',
                'price' => 1800000,
                'img' => 'dreamyluxurious.jpg',
                'category_id' => 3,
            ),
            array(
                'name' => 'Creamy Magical Unicorn Blossom Box',
                'description' => 'Favourite Blossom Box Flower',
                'price' => 2200000,
                'img' => 'magicalunicorn.jpg',
                'category_id' => 4,
            ),
            array(
                'name' => 'Pink Clouds Blooming Basket',
                'description' => 'Favourite Blossom Box Flower',
                'price' => 1800000,
                'img' => 'pinkcloud.jpg',
                'category_id' => 4,
            ),
            array(
                'name' => 'Sunset on Mars',
                'description' => 'Favourite Blossom Box Flower',
                'price' => 2200000,
                'img' => 'sunsetonmars.jpg',
                'category_id' => 4,
            ),
            array(
                'name' => 'Fall Romance Blossom Box',
                'description' => 'Favourite Blossom Box Flower',
                'price' => 2200000,
                'img' => 'fallromance.jpg',
                'category_id' => 4,
            ),
            array(
                'name' => 'Cameron Luxury Red Wine Blossom Box',
                'description' => 'Favourite Blossom Box Flower',
                'price' => 2200000,
                'img' => 'luxuryredwine.jpg',
                'category_id' => 4,
            ),
        ));
    }
}
