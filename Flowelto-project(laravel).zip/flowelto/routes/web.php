<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','MainController@home');
Route::get('/logout','UserController@logout')->name('logout');
Route::post('/login','UserController@login')->name('login');
Route::get('/login','MainController@login')->name('login');
Route::post('/register','UserController@register')->name('register');
Route::get('/register','MainController@register')->name('register');
Route::get('/category/{id}','MainController@category')->name('category');
Route::get('/flowerDetail/{id}','MainController@flowerDetail')->name('detail');
Route::post('/addtocart/{id}','CartController@add')->name('addtocart');
Route::post('/addFlower','FlowerController@add')->name('addflower');
Route::get('/addFlower','MainController@addFlower')->name('addflower');
Route::get('/manageCategory','MainController@manageCategory')->name('managecategory');
Route::post('/deleteCategory/{id}','CategoryController@delete')->name('deletecategory');
Route::post('/updateCategory/{id}','CategoryController@update')->name('updatecategory');
Route::get('/updateCategory/{id}','MainController@updateCategory')->name('updatecategory');
Route::get('/mycart','MainController@myCart')->name('mycart');
Route::post('/updateCart/{id}','CartController@update')->name('updatecart');
Route::post('/checkout','CartController@checkout')->name('checkout');
Route::get('/transactionHistory','MainController@transactionHistory')->name('transactionhistory');
Route::get('/transactionDetail/{id}','MainController@transactionDetail')->name('transactiondetail');
Route::post('/deleteFlower/{id}','FlowerController@delete')->name('deleteflower');
Route::post('/updateFlower/{id}','FlowerController@update')->name('updateflower');
Route::get('/updateFlower/{id}','MainController@updateFlower')->name('updateflower');
Route::post('/changePassword','UserController@changePassword')->name('changepassword');
Route::get('/changePassword','MainController@changePassword')->name('changepassword');